
const serverless = require('serverless-http');
const app = require('./index');

module.exports.index = serverless(app);



