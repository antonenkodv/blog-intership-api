const {Router} = require('express')

const router = Router()

// '/user'
router.get('/', (req,res)=>{

})

module.exports = router